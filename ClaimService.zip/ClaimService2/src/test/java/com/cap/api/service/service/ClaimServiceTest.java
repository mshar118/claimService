package com.cap.api.service.service;

import com.cap.api.service.entity.Claim;
import com.cap.api.service.paymentapp.service.InvoiceService;
import com.cap.api.service.repository.ClaimRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ClaimServiceTest {

    @Mock
    private ClaimRepository claimRepository;

    @InjectMocks
    private ClaimService claimService;

    @Mock
    private InvoiceService invoiceService;

    private Claim validClaim;
    private Claim expiredClaim;


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        validClaim = new Claim();
        validClaim.setClaimId(1);
        validClaim.setClaimAmount(5000);
        validClaim.setClaimDate(LocalDate.now().minusMonths(1));
        validClaim.setClaimStatus(null); // Not yet processed

        expiredClaim = new Claim();
        expiredClaim.setClaimId(2);
        expiredClaim.setClaimAmount(5000);
        expiredClaim.setClaimDate(LocalDate.now().minusMonths(7)); // Older than 6 months
        expiredClaim.setClaimStatus(null);
    }

    @Test
    public void approveClaim_Success() {
        when(claimRepository.findById(1)).thenReturn(Optional.of(validClaim));
        when(claimRepository.save(validClaim)).thenReturn(validClaim);
        String response = claimService.approveClaim(1, "John Doe");
        assertEquals("Claim 1 approved successfully by John Doe.", response);
    }

    @Test
    public void approveClaim_ClaimNotFound() {
        when(claimRepository.findById(999)).thenReturn(Optional.empty());
        Exception exception = org.junit.jupiter.api.Assertions.assertThrows(RuntimeException.class, () -> {
            claimService.approveClaim(999, "John Doe");
        });
        assertEquals("Claim ID not found.", exception.getMessage());
    }


    @Test
    public void approveClaim_InvalidClaimDate() {
        when(claimRepository.findById(2)).thenReturn(Optional.of(expiredClaim));
        String response = claimService.approveClaim(2, "John Doe");
        assertEquals("Claim 2 has an invalid claim date.", response);
    }
}