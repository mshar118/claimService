package com.cap.api.service.service;
// Genrate code documentation for all methods in this class
 
import com.cap.api.service.entity.Claim;
import com.cap.api.service.paymentapp.model.Invoice;
import com.cap.api.service.paymentapp.service.InvoiceService;
import com.cap.api.service.repository.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.List;

@Service
public class ClaimService {

    @Autowired
    private ClaimRepository claimRepository;
    @Autowired
    private InvoiceService invoiceService;


    //write a method to insert a claim
    public Claim insertClaim(Claim claim) {
        return claimRepository.save(claim);
    }

    //write a method to get all claims
    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }



    //write a method to get a claim by id
    public Claim getClaimById(int claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new RuntimeException("Claim ID not found."));
    }

    /**
 * Approves a claim based on the given claim ID and approver.
 *
 * @param claimId    The unique identifier of the claim to be approved.
 * @param approvedBy The name or identifier of the person approving the claim.
 * @return A String message indicating the result of the approval process.
 * @throws RuntimeException If the claim with the given ID is not found.
 *
 * This method performs the following checks and actions:
 * 1. Checks for unpaid invoices associated with the claim.
 * 2. Verifies if the claim exists.
 * 3. Checks if the claim has already been processed.
 * 4. Validates the claim date.
 * 5. If all checks pass, approves the claim and updates its status.
 *
 * Approval Conditions:
 * - The client must have no more than one unpaid invoice.
 * - The claim must not have been previously processed.
 * - The claim date must be within the last 6 months and not in the future.
 *
 * If any condition is not met, an appropriate error message is returned.
 */

    public String approveClaim(int claimId, String approvedBy) {
        List<Invoice> unpaidInvoices = invoiceService.getUnpaidInvoicesForClients(claimId);

        if (unpaidInvoices.size() > 1) {
            return "You have more than 1 unpaid premium. Max allowed unpaid invoice is 1 for approving your upcoming claims";
        }
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new RuntimeException("Claim ID not found."));

        if (claim.getClaimStatus() != null) {
            return "Claim " + claimId + " has already been " + claim.getClaimStatus() + ".";
        } else if (claim.getClaimDate().isAfter(LocalDate.now()) || claim.getClaimDate().isBefore(LocalDate.now().minusMonths(6))) {
            return "Claim " + claimId + " has an invalid claim date.";
        } else {
            claim.setClaimStatus("Approved");
            claimRepository.save(claim);
            return "Claim " + claimId + " approved successfully by " + approvedBy + ".";
        }
    }
}