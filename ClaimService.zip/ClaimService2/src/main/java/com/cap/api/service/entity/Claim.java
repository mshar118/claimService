package com.cap.api.service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDate;

@Data
@Entity
public class Claim {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int claimId;
    private String claimReason;
    private String claimType;
    private double claimAmount;
    private LocalDate claimDate;
    private String claimStatus;

}