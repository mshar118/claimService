# ClaimServiceApplication Documentation

## Table of Contents
1. [Introduction](#introduction)
2. [System Architecture](#system-architecture)
3. [Class Descriptions](#class-descriptions)
4. [API Endpoints](#api-endpoints)
5. [Database Schema](#database-schema)
6. [Business Logic](#business-logic)
7. [Error Handling](#error-handling)
8. [Testing](#testing)
9. [Deployment](#deployment)
10. [Diagrams](#diagrams)

## 1. Introduction <a name="introduction"></a>

The ClaimServiceApplication is a Spring Boot application that manages insurance claims. It provides functionalities for adding claims, retrieving individual claims, listing all claims, and approving claims based on specific business rules.

## 2. System Architecture <a name="system-architecture"></a>

The application follows a typical Spring Boot architecture with the following layers:

1. Controller Layer: Handles HTTP requests and responses
2. Service Layer: Contains business logic
3. Repository Layer: Interfaces with the database
4. Entity Layer: Represents database tables as Java objects

The application uses an H2 in-memory database for data storage.

## 3. Class Descriptions <a name="class-descriptions"></a>

### 3.1 Claim

This is an entity class representing the CLAIM table in the database.

```java
@Entity
public class Claim {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String customerName;
  private String policyNumber;
  private LocalDate incidentDate;
  private Double claimAmount;
  private String claimType;
  private String description;
  private String status;

  // Getters and setters
}
```

### 3.2 ClaimRepository

This interface extends JpaRepository to provide CRUD operations for the Claim entity.

### 3.3 ClaimService

This service class contains the business logic for managing claims.

### 3.4 ClaimController

This controller class handles HTTP requests for claim operations.

## 4. API Endpoints <a name="api-endpoints"></a>

- `POST /api/claims` - Add a new claim
- `GET /api/claims/{id}` - Retrieve a specific claim
- `GET /api/claims` - Retrieve all claims
- `PUT /api/claims/{id}/approve` - Approve a claim

## 5. Database Schema <a name="database-schema"></a>

The application uses a single table named CLAIM with the following schema:

| Column Name    | Data Type | Constraints                  |
|----------------|-----------|------------------------------|
| id             | BIGINT    | Primary Key, Auto Increment  |
| customer_name  | VARCHAR   | Not Null                     |
| policy_number  | VARCHAR   | Not Null                     |
| incident_date  | DATE      | Not Null                     |
| claim_amount   | DOUBLE    | Not Null                     |
| claim_type     | VARCHAR   | Not Null                     |
| description    | VARCHAR   |                              |
| status         | VARCHAR   | Not Null                     |

## 6. Business Logic <a name="business-logic"></a>

The main business logic is implemented in the ClaimService class:

- When adding a new claim, the status is automatically set to "Pending".
- Approving a claim is conditional:
  - If there are more than one unpaid invoices, the claim cannot be approved.
  - If the claim can be approved, its status is updated to "Approved".

## 7. Error Handling <a name="error-handling"></a>

The application uses exception handling to manage errors:

- `RuntimeException` is thrown when a claim is not found.
- Custom error messages are returned for business rule violations (e.g., too many unpaid invoices).

## 8. Testing <a name="testing"></a>

(Note: Test classes are not provided in the given code. Here's a suggestion for testing strategy)

- Unit tests should be written for each class, particularly the ClaimService.
- Integration tests should be created to test the full flow from HTTP request to database update.
- Use MockMvc for testing the controller.
- Use an in-memory H2 database for integration tests.

## 9. Deployment <a name="deployment"></a>

The application can be deployed as a standalone JAR file. To build and run:

- Build the JAR: `./mvnw clean package`
- Run the JAR: `java -jar target/claimservice-0.0.1-SNAPSHOT.jar`

## 10. Diagrams <a name="diagrams"></a>

### 10.1 Class Diagram

![Class Diagram](./classDiagram.png)

### 10.2 Sequence Diagram

![Sequence Diagram](./sequenceDiagram.png)

### 10.3 Database Schema Diagram

![Database Schema Diagram](./dataBaseDiagram.png)

### 10.4 API Flow Diagram

![API Flow Diagram](./apiFlowDiagram.png)

```yaml
openapi: 3.0.0
info:
  title: Claim Service API
  description: API for managing insurance claims
  version: 1.0.0

servers:
  - url: http://localhost:8080/api

paths:
  /claims:
  post:
    summary: Add a new claim
    requestBody:
    required: true
    content:
      application/json:
      schema:
        $ref: '#/components/schemas/ClaimInput'
    responses:
    '200':
      description: Successful operation
      content:
      application/json:
        schema:
        $ref: '#/components/schemas/Claim'
    '400':
      description: Invalid input
  get:
    summary: Get all claims
    responses:
    '200':
      description: Successful operation
      content:
      application/json:
        schema:
        type: array
        items:
          $ref: '#/components/schemas/Claim'

  /claims/{id}:
  get:
    summary: Get a claim by ID
    parameters:
    - name: id
      in: path
      required: true
      schema:
      type: integer
      format: int64
    responses:
    '200':
      description: Successful operation
      content:
      application/json:
        schema:
        $ref: '#/components/schemas/Claim'
    '404':
      description: Claim not found

  /claims/{id}/approve:
  put:
    summary: Approve a claim
    parameters:
    - name: id
      in: path
      required: true
      schema:
      type: integer
      format: int64
    responses:
    '200':
      description: Approval status
      content:
      application/json:
        schema:
        type: string
    '404':
      description: Claim not found

components:
  schemas:
  ClaimInput:
    type: object
    required:
    - customerName
    - policyNumber
    - incidentDate
    - claimAmount
    - claimType
    properties:
    customerName:
      type: string
    policyNumber:
      type: string
    incidentDate:
      type: string
      format: date
    claimAmount:
      type: number
      format: double
    claimType:
      type: string
    description:
      type: string

  Claim:
    type: object
    properties:
    id:
      type: integer
      format: int64
    customerName:
      type: string
    policyNumber:
      type: string
    incidentDate:
      type: string
      format: date
    claimAmount:
      type: number
      format: double
    claimType:
      type: string
    description:
      type: string
    status:
      type: string
```